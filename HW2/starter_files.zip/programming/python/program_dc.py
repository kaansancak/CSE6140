"""
Starter template for dynamic programming
CSE6140, Fall 2019
"""
import sys


if __name__ == '__main__':

	args = sys.argv
	if len(args) != 3:
		sys.exit("Usage: {} [input] [output]".format(args[0]))

	in_file_path = sys.argv[1]
	out_file_path = sys.argv[2]

	# Your code
   
    # Write results to output